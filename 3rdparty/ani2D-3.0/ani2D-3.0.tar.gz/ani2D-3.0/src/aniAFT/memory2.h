#ifndef H_MEMORY2_MESH2D
#define H_MEMORY2_MESH2D


#include"struct2.h"


/* exported  function  function */
void Near *nearAlloc( unsigned int n );
void initMemory( void );
void freeMemory(void);


#endif
