#ifndef H_TRIA2_MESH2D
 #define H_TRIA2_MESH2D


#include"struct2.h"


int makeTria( void );


#endif
