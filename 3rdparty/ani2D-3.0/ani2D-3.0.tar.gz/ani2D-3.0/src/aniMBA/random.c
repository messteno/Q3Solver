#include <stdlib.h>


void random_( double *value ) 
{
   *value = (double)rand() / RAND_MAX;
}
